# ecopax-shipping-performance-reviewer
A standalone piece of software that allows for the uploading of excel sheets exported from the Transwide Shipping System, and analyzes them to provide statistics on worker performance
